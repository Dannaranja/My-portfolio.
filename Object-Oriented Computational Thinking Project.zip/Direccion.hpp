#include <iostream>

using namespace std;

// Programado por Alejandra
class Direccion
{
  // atributo
  private:
  string residencial;
  string calle;
  string pais;

  // Metodos
  public:
  // Constructor default
  Direccion();

  // Constructor con parametros
  Direccion(string residencial, string calle, string pais);

  // Setters
  void setResidencial(string residencial);
  void setCalle(string calle);
  void setPais(string pais);

  // Getters
  string getResidencial();
  string getCalle();
  string getPais();
};

// Implementación de metodos

// Constructor Default
Direccion :: Direccion()
{
  residencial = "-";
  calle = "-";
  pais = "-";
}

// Constructor con parametros
Direccion :: Direccion(string residencial, string calle, string pais)
{
  this->residencial = residencial;
  this->calle = calle;
  this->pais = pais;
}

// Set Residencial
void Direccion :: setResidencial(string residencial)
{
  this->residencial = residencial; 
}

// Set Calle
void Direccion :: setCalle(string calle)
{
  this->calle = calle;
}

// Set Pais
void Direccion :: setPais(string pais)
{
  this->pais = pais;
}

// Get Residencial
string Direccion :: getResidencial()
{
  return residencial;
}

// Get Calle
string Direccion :: getCalle()
{
  return calle;
}

// Get Pais
string Direccion :: getPais()
{
  return pais;
}