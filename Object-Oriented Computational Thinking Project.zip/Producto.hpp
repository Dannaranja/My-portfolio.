#include <iostream>
using namespace std;

class Producto {
public:
    //constructores
    Producto();
    Producto(string nom, int cant, double precio);

    //metodos de acceso
    int getCantidad();
    string getNombre();
    double getPrecio();

    //metodos de modificacion
    void setCantidad(int cant);
    void setNombre(string nom);
    void setPrecio(double precio);


private:
   int cantidad;
   string nombre;
   double precio;

};

Producto::Producto() {
    cantidad = 0;
    nombre = "";
}

Producto::Producto(string nombre, int cantidad, double precio) {
    this->nombre = nombre;
    this->cantidad = cantidad;
    this->precio = precio;
}

int Producto::getCantidad() {
    return cantidad;
}

string Producto::getNombre() {
    return nombre;
}

double Producto :: getPrecio(){
    return precio;
}

void Producto::setCantidad(int cant) {
    cantidad = cant;
}

void Producto::setNombre(string nom) {
    nombre = nom;
}

void Producto::setPrecio(double precio){
    this->precio = precio;
}