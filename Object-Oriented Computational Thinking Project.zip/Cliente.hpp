#include <iostream>

using namespace std;

#include "Direccion.hpp"

// Programado por Danna
class Cliente
{
  // Atributos
  private:
  int ident;
  string nombre;
  string apellido;
  Direccion residencia;

  // Metodos
  public:
  // Constructor default
  Cliente();

  // Constructor con parametros
  Cliente(int ident, string nombre, string apellido, Direccion residencia);

  // Setters
  void setIdent(int ident);
  void setNombre(string nombre);
  void setApellido(string appelido);
  void setResidencia(Direccion residencia);

  // Getters
  int getIdent();
  string getNombre();
  string getApellido();
  Direccion getResidencia();

  // Metodo para desplegar datos
  void despliegaDatos();
};

// Implementacion de metodos

// Constructor Default
Cliente :: Cliente()
{
  Direccion r("-", "-", "-");
  ident = 0;
  nombre = "-";
  apellido = "-";
  residencia = r;
}

// Constructor con parametros
Cliente :: Cliente(int ident, string nombre, string apellido, Direccion residencia)
{
  this->ident = ident;
  this->nombre = nombre;
  this->apellido = apellido;
  this->residencia = residencia;
}

// Set Ident
void Cliente :: setIdent(int ident)
{
  this->ident = ident;
}

// Set Nombre
void Cliente :: setNombre(string nombre)
{
  this->nombre = nombre;
}

// Set Apellido
void Cliente :: setApellido(string apellido)
{
  this->apellido = apellido;
}

// Set Residencia
void Cliente :: setResidencia(Direccion residencia)
{
  this->residencia = residencia; 
}

// Get Ident
int Cliente :: getIdent()
{
  return ident;
}

// Get Nombre
string Cliente :: getNombre()
{
  return nombre;
}

// Get Apellido
string Cliente :: getApellido()
{
  return apellido;
} 

// Get Residencia
Direccion Cliente :: getResidencia()
{
  return residencia;
}

void Cliente :: despliegaDatos()
{
  cout << "Tus datos son los siguientes: " << endl;
  cout << "Nombre: " << nombre << endl;
  cout << "Apellido: " << apellido << endl;
  cout << "Id: " << ident << endl;
  cout << "Dirección: " << residencia.getResidencial() << ", " << residencia.getCalle() << ", " << residencia.getPais() << endl;
}

