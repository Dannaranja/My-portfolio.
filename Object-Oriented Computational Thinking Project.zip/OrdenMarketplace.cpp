#include <iostream>

using namespace std;

#include <string>
#include "Cliente.hpp"
#include "Producto.hpp"
#include "PagoTotal.hpp"

//Programado por Alejandra
// Función Lista de Productos
void listaProductos(Producto arr[])
{
  // Lista de productos
  cout << "Añade los productos a tu carrito" << endl;
  cout << "1. " << arr[0].getNombre() << " $" << arr[0].getPrecio() << endl;
  cout << "2. " << arr[1].getNombre() << " $" << arr[1].getPrecio() << endl;
  cout << "3. " << arr[2].getNombre() << " $" << arr[2].getPrecio() << endl;
  cout << "4. " << arr[3].getNombre() << " $" << arr[3].getPrecio() << endl;
  cout << "5. " << arr[4].getNombre() << " $" << arr[4].getPrecio() << endl;
  cout << "6. " << arr[5].getNombre() << " $" << arr[5].getPrecio() << endl;
  cout << "7. " << arr[6].getNombre() << " $" << arr[6].getPrecio() << endl;
  cout << "8. " << arr[7].getNombre() << " $" << arr[7].getPrecio() << endl;
}

//Programado por Alejandra
void escogeProductos(Producto listaUsuario[], Producto listaMenu[], int cantidad)
{
  int num;
  int cantidadProducto;

  for(int i = 0; i < cantidad; i++)
  {
    cout << "Teclea el número del producto" << endl;
    cin >> num;
    num = num - 1;

    if(num >= 0 && num < 8)
    {
      cout << "Teclea la cantidad de este producto" << endl;
      cin >> cantidadProducto; 
      listaUsuario[i].setNombre(listaMenu[num].getNombre());
      listaUsuario[i].setPrecio(listaMenu[num].getPrecio());
    }
    else
    {
      cout << "Escoge un producto de la lista" << endl;
      i = i-1;
    }
    
    listaUsuario[i].setCantidad(cantidadProducto);
  }
}

//Programado por Danna

void listaCliente(Producto listaProd[], int cantidad)
{
  for(int i = 0; i < cantidad; i++)
  {
    cout << i+1 << ". " << listaProd[i].getNombre() << " " << listaProd[i].getCantidad() << endl;
  }
}

//progrmada por Danna
double pagoTotal(Producto listaProd[],int cantidad) {

  double total;
  for(int i = 0; i < cantidad; i++)
  {
    if(listaProd[i].getNombre() == "Plumon")
    {
       total = total + listaProd[i].getCantidad() * 20.0;
    }
    else if (listaProd[i].getNombre() == "Lapiz") {
      total = total + listaProd[i].getCantidad() * 15.5;
    }
    else if (listaProd[i].getNombre() == "Borrador") {
      total = total + listaProd[i].getCantidad() * 11.99;
    }
    else if(listaProd[i].getNombre() == "Libreta") {
      total = total + listaProd[i].getCantidad() * 199.99;
    }
    else if(listaProd[i].getNombre() == "Tijeras") {
      total = total + listaProd[i].getCantidad() * 76.0;
    }
    else if(listaProd[i].getNombre() == "Marcador") {
      total = total + listaProd[i].getCantidad() * 80.0;
    }
    else if(listaProd[i].getNombre() == "Post its") {
      total = total + listaProd[i].getCantidad() * 200.0;
    }
    else if (listaProd[i].getNombre() == "Papel") {
      total = total + listaProd[i].getCantidad() * 120.0;
    }
  }
  return total;
}

// Clase Main
int main()
{
  //Programado por Danna
  // Declarar elementos de usuario
  Cliente usuario;
  char opcion;
  int ident;
  string nombre, apellido, residencial, calle, pais;
  Direccion residencia;

  //Programado por Danna
  // Lista del Menu
  Producto  utiles[8];
  utiles[0].setNombre("Plumon");
  utiles[0].setPrecio(20.0); 
  utiles[1].setNombre("Lapiz");
  utiles[1].setPrecio(15.5);
  utiles[2].setNombre("Borrador");
  utiles[2].setPrecio(11.99);
  utiles[3].setNombre("Libreta");
  utiles[3].setPrecio(199.99);
  utiles[4].setNombre("Tijeras");
  utiles[4].setPrecio(76.0); 
  utiles[5].setNombre("Marcador");
  utiles[5].setPrecio(80.0);
  utiles[6].setNombre("Post its");
  utiles[6].setPrecio(200.0);
  utiles[7].setNombre("Papel");
  utiles[7].setPrecio(120.0);

  //Programado por Alejandra
  Producto listaProductosUsuario[20];
  PagoTotal totalAPagar;
  string metodo;
  int numeroTarjeta;
  double total;
  
  int cantidad;
    

  // Correr el menu mientras no se elija finalizar
  while (opcion != 'd')
  {
    // Lista de opciones
    cout << "a. Ingresa tus datos " << endl;
    cout << "b. Añade tus productos" << endl;
    cout << "c. Realiza el pago" << endl;
    cout << "d. Finalizar" << endl;
    
    // Ingresa la letra de la opción
    cout << "Ingresa la letra de la opción" << endl;
    cin >> opcion;

    switch (opcion)
    {
    //Programado por Alejandra y Danna
    // Ingresar Datos
    case 'a':
      // Ingresar Id
      cout << "Ingresa tu número de cuenta" << endl;
      cin >> ident;

      // Ingresar Nombre
      cout << "Ingresa tu nombre: " << endl;
      cin >> nombre;

      cout << "Ingresa tu apellido: " << endl;
      cin >> apellido;
      
      // Ingresar dirección
      cout << "Ingresa tu dirección" << endl;
      cout << "Residencial: " << endl;
      cin >> residencial;

      cout << "Calle: " << endl;
      cin >> calle;

      cout << "País: " << endl;
      cin >> pais;
      
      // Modificar datos en el objeto
      usuario.setIdent(ident);
      usuario.setNombre(nombre);
      usuario.setApellido(apellido);
      residencia.setResidencial(residencial);
      residencia.setCalle(calle);
      residencia.setPais(pais);
      usuario.setResidencia(residencia);

      // Mostrar como quedan los datos
      usuario.despliegaDatos();
      break;
    
    case 'b':

      // Desplegar lista de productos
      //Programado por Danna
      listaProductos(utiles);

      cout << "¿Cuantos productos deseas?" << endl;
      cin >> cantidad;

      escogeProductos(listaProductosUsuario, utiles, cantidad);

      listaCliente(listaProductosUsuario, cantidad);
      break;

    case 'c':

      //Programado por Danna
      total = pagoTotal(listaProductosUsuario, cantidad);
      cout << "Ingresa tu metodo de pago (tarjeta, puntos o efectivo)" << endl;
      cin >> metodo;

      totalAPagar.setCantidadPagar(total);

      while(metodo != "tarjeta" && metodo != "puntos" && metodo != "efectivo")
      {
        cout << "Metodo de pago invalido vuelve a intentarlo" << endl;
        cin >> metodo;
      }
      totalAPagar.setMetodoDePago(metodo);

      if(metodo == "tarjeta")
      {
        cout << "Ingresa tu número de tarjeta" << endl;
        cin >> numeroTarjeta;
      }
      
      listaCliente(listaProductosUsuario, cantidad);
      cout << "Tu total a pagar es de: $" << totalAPagar.getCantidadPagar() << endl;
      break;
      
    default:
      cout << "Ingresa una opcion valida" << endl;
      break;
    }
  }
  
  //Programado por Alejandra
  // Desplegar Datos de finalización de compra
  usuario.despliegaDatos();
  if(numeroTarjeta > 0)
  {
    cout << "Numero de Tarjeta: " << numeroTarjeta << endl;
  }
  listaCliente(listaProductosUsuario, cantidad);
  cout << "Total de pago: $" << total << endl;

  return 0;
}