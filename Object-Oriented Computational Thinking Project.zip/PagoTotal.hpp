#include <iostream>

using namespace std;

class PagoTotal
{
  // Atributos programado por Alejandra y Danna
  private:
  double cantidadPagar;
  string metodoDePago;

  // Metodos
  public:
  // Constructor default
  PagoTotal();

  // Constructor con parametros
  PagoTotal(double cantidadPagar, string metodoDePago);

  // Setters
  void setCantidadPagar(double cantidadPagar);
  void setMetodoDePago(string metodoDePago);

  // Getters
  double getCantidadPagar();
  string getMetodoDePago();
};

// Implementación de Metodos

// Constructor Default
PagoTotal :: PagoTotal()
{
  cantidadPagar = 0;
  metodoDePago = '-';
}

// Constructor con Parametros
PagoTotal :: PagoTotal(double cantidadPagar, string metodoDePago)
{
  this->cantidadPagar = cantidadPagar;
  this->metodoDePago = metodoDePago;
}

// Set Cantidad a Pagar
void PagoTotal :: setCantidadPagar(double cantidadPagar)
{
  this->cantidadPagar = cantidadPagar;
}

// Set Metodo de Pago
void PagoTotal :: setMetodoDePago(string metodoDePago)
{
  this->metodoDePago = metodoDePago;
}

// Get Ident
double PagoTotal :: getCantidadPagar()
{
  return cantidadPagar;
}

// Get Nombre
string PagoTotal :: getMetodoDePago()
{
  return metodoDePago;
}
